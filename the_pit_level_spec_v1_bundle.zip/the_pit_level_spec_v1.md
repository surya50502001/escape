# The Pit — Technical Level Specification v1

**Status:** Proposed implementation spec; all coordinates and timing are initial design values and require in-game validation.  
**Camera/style:** Clean 2D cartoon, side-scrolling with horizontal movement and vertical climbing.  
**Team:** 4–5 players, one cooperative team.  
**Coordinate convention:** Room-local abstract tiles, origin at bottom-left, X=0..50, Y=0..20. Rectangles are `[x_min, x_max, y_min, y_max]`.

## Non-negotiable global rules

1. Server-authoritative movement validation, interactions, inventory, guards, puzzle state, and transitions.
2. One carried item per player. Pickup/drop/handoff must be atomic.
3. A disconnect must not destroy or duplicate an item. Return carried items to a deterministic safe location.
4. Room state persists across visits.
5. Mandatory items have fixed, guaranteed locations. No random mandatory-item placement.
6. No irreversible traps, mandatory-item softlocks, or indefinite capture states.
7. Team transitions must support regrouping/recovery if a player is disconnected, captured, or separated.
8. All dimensions below are proposed, not proven. Validate against actual movement physics and collision shapes.

## Room specifications

### Room 1 — Cell

- **Bounds:** X 0–50, Y 0–20.
- **Geometry:**
  - `main_floor` (platform): rect `[0, 18, 2, 3]`; mandatory.
  - `boost_zone` (safe_zone): rect `[8, 13, 2, 5]`; mandatory.
  - `upper_ledge` (platform): rect `[20, 34, 9, 10]`; mandatory.
  - `rope_anchor` (anchor): point `[31, 9]`; mandatory.
  - `exit_door` (door): rect `[47, 8, 49, 11]`; mandatory.
- **Intended solution:**
  - Three players form a cooperative boost for a fourth player.
  - The elevated player reaches the anchor and secures a climbable rope.
  - Remaining players climb; regroup at the exit and transition together.
- **Recovery / anti-softlock:**
  - Failed boosts reset player positions to the safe boost zone.
  - Anchor interaction has a clear success/failure result.
  - If rope placement fails, the anchor can be retried without consuming an item.
- **Persisted state:** `anchor_secured`, `rope_deployed`, `players_in_exit_zone`.
- **Resolve before calling this room implementation-ready:**
  - Define the exact boost interaction and physics so the puzzle works with exactly four players.
  - Define rope length and how rope attachment is synchronized.

### Room 2 — First Climb

- **Bounds:** X 0–50, Y 0–20.
- **Geometry:**
  - `main_floor` (platform): rect `[0, 50, 2, 3]`; mandatory.
  - `chair` (movable): rect `[12, 2, 13, 3]`; optional.
  - `crate` (movable): rect `[18, 2, 20, 3]`; optional.
  - `raised_ledge` (platform): rect `[25, 40, 8, 9]`; mandatory.
  - `exit_door` (door): rect `[47, 8, 49, 11]`; mandatory.
- **Intended solution:**
  - Stack chair and crate to reach the ledge, or use a teammate boost.
  - Cross the ledge and regroup at the exit.
- **Recovery / anti-softlock:**
  - Movables are clamped to safe room bounds.
  - If objects become wedged, a server-validated reset returns them to their spawn transforms.
- **Persisted state:** `chair_transform`, `crate_transform`, `room_completed`.

### Room 3 — Sleeping Guard

- **Bounds:** X 0–50, Y 0–20.
- **Geometry:**
  - `main_floor` (platform): rect `[0, 50, 2, 3]`; mandatory.
  - `cover_a` (cover): rect `[14, 18, 2, 4]`; mandatory.
  - `cover_b` (cover): rect `[30, 34, 2, 4]`; mandatory.
  - `guard` (guard_spawn): point `[24, 2]`; mandatory.
  - `noisy_crate` (movable): rect `[19, 2, 21, 3]`; optional.
  - `bypass_ledge` (platform): rect `[21, 7, 31, 8]`; optional.
- **Intended solution:**
  - Move quietly from cover to cover or use the higher bypass.
  - Noisy actions wake the guard and initiate search/chase.
- **Recovery / anti-softlock:**
  - Capture relocates only the caught player to a nearby holding nook.
  - A release/rescue path must be available and must not depend on a single missable item.
- **Persisted state:** `guard_alert_state`, `guard_patrol_phase`, `capture_flags`, `object_transforms`.
- **Resolve before calling this room implementation-ready:**
  - Specify detection radius, noise radius, chase timeout, and holding-nook release mechanism.

### Room 4 — Sweeping Searchlight

- **Bounds:** X 0–50, Y 0–20.
- **Geometry:**
  - `main_floor` (platform): rect `[0, 50, 2, 3]`; mandatory.
  - `cover_a` (cover): rect `[12, 16, 2, 5]`; mandatory.
  - `cover_b` (cover): rect `[29, 33, 2, 5]`; mandatory.
  - `beam_sweep` (hazard_path): path/range `{'x_range': [5, 45], 'cycle_seconds': 8}`; mandatory.
- **Intended solution:**
  - Move between solid cover pockets during safe sweep windows.
  - Beam phase is server-driven; cover occlusion is evaluated server-side.
- **Recovery / anti-softlock:**
  - Exposure raises alert but does not cause a hard fail.
  - Alert decay or guard reset must allow another attempt.
- **Persisted state:** `beam_phase`, `beam_timer`, `player_alert_state`.
- **Resolve before calling this room implementation-ready:**
  - Define beam width, sweep curve, phase offset, occlusion shape, and safe windows after playtesting.

### Room 5 — Hidden Compartment

- **Bounds:** X 0–50, Y 0–20.
- **Geometry:**
  - `main_floor` (platform): rect `[0, 50, 2, 3]`; mandatory.
  - `movable_panel` (movable_panel): rect `[25, 3, 27, 6]`; optional.
  - `exit_door` (door): rect `[47, 2, 49, 5]`; mandatory.
- **Items:**
  - `optional_rope` (rope), optional.
- **Intended solution:**
  - Slide the panel to reveal an optional clue and reusable rope.
  - The primary exit is reachable without discovering the compartment.
- **Recovery / anti-softlock:**
  - Panel movement is reversible.
  - Undiscovered optional items remain in place.
- **Persisted state:** `panel_transform`, `compartment_revealed`, `optional_item_state`.

### Room 6 — Vertical Shaft

- **Bounds:** X 0–25, Y 0–20.
- **Geometry:**
  - `lower_floor` (platform): rect `[0, 25, 1, 2]`; mandatory.
  - `entry_ledge` (platform): rect `[0, 8, 16, 17]`; mandatory.
  - `pipe` (climbable): rect `[8, 8, 9, 15]`; mandatory.
  - `ladder` (climbable): rect `[13, 2, 14, 15]`; mandatory.
  - `rope_anchor` (anchor): point `[19, 15]`; mandatory.
  - `recovery_platform` (platform): rect `[7, 18, 3, 4]`; mandatory.
  - `exit_door` (door): rect `[23, 15, 25, 18]`; mandatory.
- **Intended solution:**
  - Use pipe, ladder, and rope anchor to reach the upper-right exit.
- **Recovery / anti-softlock:**
  - Any fall routes the player to the lower recovery platform.
  - The recovery platform must connect back to a climbable route.
- **Persisted state:** `climb_state`, `recovery_trigger_state`.
- **Resolve before calling this room implementation-ready:**
  - Confirm that the recovery platform is connected to the ladder/pipe route and that no fall can bypass it.

### Room 7 — Patrol Route

- **Bounds:** X 0–50, Y 0–20.
- **Geometry:**
  - `main_floor` (platform): rect `[0, 50, 2, 3]`; mandatory.
  - `cover_a` (cover): rect `[10, 14, 2, 4]`; mandatory.
  - `cover_b` (cover): rect `[34, 38, 2, 4]`; mandatory.
  - `guard_patrol` (patrol_path): path/range `{'x_range': [18, 31], 'y': 2}`; mandatory.
  - `distraction_item` (distraction): point `[8, 2]`; optional.
  - `vent_shortcut` (shortcut): path/range `{'start': [14, 8], 'end': [35, 8], 'noisy': True}`; optional.
- **Intended solution:**
  - Use a distraction and covered floor route, or risk the faster noisy vent shortcut.
- **Recovery / anti-softlock:**
  - Chase has a timeout/reset.
  - Vent can be exited from either end and cannot trap a player.
- **Persisted state:** `guard_position`, `guard_alert_state`, `distraction_state`, `vent_state`.
- **Resolve before calling this room implementation-ready:**
  - Specify vent entrance/exit hitboxes and ensure the shortcut is reachable without mandatory inventory.

### Room 8 — Two-Switch Puzzle

- **Bounds:** X 0–50, Y 0–20.
- **Geometry:**
  - `main_floor` (platform): rect `[0, 50, 2, 3]`; mandatory.
  - `switch_a` (switch): point `[12, 2]`; mandatory.
  - `switch_b` (switch): point `[36, 2]`; mandatory.
  - `crate` (movable): rect `[24, 2, 26, 3]`; mandatory.
  - `exit_door` (door): rect `[47, 2, 49, 5]`; mandatory.
- **Intended solution:**
  - Place crate on switch A or B; a player activates the other switch.
  - When both are active, open exit for a 5-second team passage window.
- **Recovery / anti-softlock:**
  - Crate has a reset action.
  - Door closes only after a safe grace period and must not crush or trap players.
- **Persisted state:** `switch_a_active`, `switch_b_active`, `crate_transform`, `door_grace_timer`.
- **Resolve before calling this room implementation-ready:**
  - Define whether switches latch or require continuous pressure; ensure all 4–5 players can pass in the grace period or provide a reopen mechanism.

### Room 9 — Locked Storage

- **Bounds:** X 0–50, Y 0–20.
- **Geometry:**
  - `main_floor` (platform): rect `[0, 50, 2, 3]`; mandatory.
  - `key_niche` (item_spawn): point `[8, 2]`; mandatory.
  - `box_a` (container): point `[20, 2]`; optional.
  - `box_b` (container): point `[28, 2]`; optional.
  - `box_c` (container): point `[36, 2]`; mandatory.
  - `exit_door` (door): rect `[47, 2, 49, 5]`; mandatory.
- **Items:**
  - `cutting_tool` (cutting_tool), mandatory, located in `box_c`.
- **Intended solution:**
  - Pick up the reusable key and open Box C for the guaranteed cutting tool.
  - Boxes A and B contain optional rewards or clues.
  - The clue explicitly identifies Box C.
- **Recovery / anti-softlock:**
  - The key cannot be permanently lost; dropped key returns to a safe point or key niche.
  - Box C remains open after opening; cutting tool persists through backtracking.
- **Persisted state:** `key_state`, `box_a_open`, `box_b_open`, `box_c_open`, `cutting_tool_state`.
- **Resolve before calling this room implementation-ready:**
  - Clarify whether the key is consumed. Recommendation: reusable, non-consumable key or server-owned box unlock state.

### Room 10 — False Escape

- **Bounds:** X 0–50, Y 0–20.
- **Geometry:**
  - `main_floor` (platform): rect `[0, 50, 2, 3]`; mandatory.
  - `platform_a` (platform): rect `[10, 18, 6, 7]`; mandatory.
  - `platform_b` (platform): rect `[20, 28, 10, 11]`; mandatory.
  - `platform_c` (platform): rect `[30, 40, 14, 15]`; mandatory.
  - `sealed_hatch` (hatch): rect `[33, 35, 18, 20]`; mandatory.
  - `cut_interaction` (interaction_zone): rect `[32, 36, 15, 17]`; mandatory.
  - `return_door` (door): rect `[0, 2, 2, 5]`; mandatory.
- **Intended solution:**
  - Reach the hatch and discover that the key alone is insufficient.
  - Return to Room 9 through the persistent return door.
  - Retrieve the cutting tool from Box C, return to Room 10, and cut the hatch.
- **Recovery / anti-softlock:**
  - Return door remains available until the hatch is cut.
  - Cutting progress is server-persisted; if tool is dropped, it remains recoverable.
- **Persisted state:** `false_escape_discovered`, `cutting_tool_used`, `hatch_cut`, `campaign_complete`.
- **Resolve before calling this room implementation-ready:**
  - Ensure the return door is reachable from the upper platform route and remains open on revisit.

## Campaign progression

`1 → 2 → 3 → 4 → 5 → 6 → 7 → 8 → 9 → 10`

Required backtrack: `10 → 9 → 10`.

Room 10's hatch cannot be cut without the mandatory cutting tool. The cutting tool is guaranteed in Room 9, Box C. Room 9 must persist its opened-box state. The key should be reusable or the unlock state should be stored server-side; never consume the only key in a way that can block Box C.

## Initial movement assumptions

- Player hitbox: 1×2 tiles.
- Small item footprint: 1×1 tile.
- Crate footprint: 2×1 tiles.
- Door clearance: 2×3 tiles.
- Tune jump height, horizontal jump reach, climb speed, rope range, push force, friction, and guard detection using the real game engine. Do not use the proposed room coordinates as proof that a jump is physically possible.

## Minimum acceptance tests

| ID | Test | Pass condition |
|---|---|---|
| T01 | Room 1 with 4 players | Complete boost/rope sequence with no fifth player or hidden item |
| T02 | Room 1 with 5 players | No collision deadlock or unintended bypass |
| T03 | One-item inventory | Pickup/drop/handoff are atomic; never two carried items |
| T04 | Disconnect carrying mandatory item | Item returns once to safe location; no loss/duplication |
| T05 | Transition with separated player | Recovery path prevents permanent team deadlock |
| T06 | Room 8 reset | Crate and switches can be reset/retried indefinitely |
| T07 | Room 9 key loss | Key cannot be permanently lost; Box C remains unlockable |
| T08 | Room 10 backtrack | 9→10→9→10 works and permits completion |
| T09 | Room persistence | Opened boxes and puzzle/object state persist on revisit |
| T10 | Guard capture | Captured player can rejoin without death or deadlock |
| T11 | Searchlight occlusion | Solid cover blocks detection server-side |
| T12 | Stuck object recovery | Object reset preserves authoritative state |

## Implementation order

1. Establish and test player physics, collision, item pickup/drop/handoff, and rope interactions.
2. Implement Room 1 only and run 4-player and 5-player tests.
3. Add authoritative room transitions and reconnect recovery.
4. Implement Rooms 2–8 one at a time with room-specific automated tests.
5. Implement Room 9 guaranteed tool placement and persistence.
6. Implement Room 10 backtracking and completion gate.
7. Run the full acceptance suite before adding the later rooftop/parachute sequence.

## Developer handoff

Treat this Markdown and JSON as the proposed source of truth for level data. The JSON is suitable for conversion into typed TypeScript room definitions, but geometry and open questions must be validated before release. This document does not claim that the rooms have been playtested.
